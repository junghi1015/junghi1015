library(shiny)
library(sf)
library(dplyr)
library(ggplot2)
library(rsconnect)


setwd("C:/Users/user/Desktop/R/8.11/Rshiny")
runApp("project_rshiny")

